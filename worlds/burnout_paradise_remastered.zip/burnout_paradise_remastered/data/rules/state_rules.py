from itertools import chain
import dataclasses
from typing import override, TYPE_CHECKING

from BaseClasses import CollectionState
from rule_builder.rules import Rule
from ..items.cars import BurningCars
from ..items.events import RaceEvents, StuntRunEvents, RoadRageEvents, MarkedManEvents
from ...constants import BURNOUT_PARADISE_REMASTERED

if TYPE_CHECKING:
    from ...world_base import BurnoutParadiseRemasteredBase


@dataclasses.dataclass(kw_only=True)
class HasEventWins(Rule["BurnoutParadiseRemasteredBase"], game=BURNOUT_PARADISE_REMASTERED):
    wins: int

    @override
    def _instantiate(self, world: "BurnoutParadiseRemasteredBase") -> Rule.Resolved:
        # caching_enabled only needs to be passed in when your world inherits from CachedRuleBuilderWorld
        return self.Resolved(wins=self.wins, player=world.player, caching_enabled=True)

    class Resolved(Rule.Resolved):
        wins: int


        @override
        def _evaluate(self, state: CollectionState) -> bool:
            LICENSE_THRESHOLDS = (2, 7, 15, 26, 40, 120)

            event_count = state.count_from_list_unique(
                [item.value for item in chain(RaceEvents, StuntRunEvents, RoadRageEvents, MarkedManEvents)],
                self.player
            )

            burning_event_count = state.count_from_list_unique(
                [item.value for item in BurningCars],
                self.player
            )

            remaining_wins = self.wins

            for threshold in LICENSE_THRESHOLDS:
                stage_wins = min(remaining_wins, threshold)
                if event_count + burning_event_count < stage_wins:
                    return False
                remaining_wins -= stage_wins
                if remaining_wins <= 0:
                    return True
            return remaining_wins <= 0

            # remaining_burning_events = burning_event_count
            #
            # for threshold in LICENSE_THRESHOLDS:
            #     stage_wins = min(remaining_wins, threshold)
            #
            #     normal_wins = min(event_count, stage_wins)
            #     missing_wins = stage_wins - normal_wins
            #
            #     burning_wins = min(remaining_burning_events, missing_wins)
            #
            #     if normal_wins + burning_wins < stage_wins:
            #         return False
            #
            #     remaining_burning_events -= burning_wins
            #     remaining_wins -= stage_wins
            #
            #     if remaining_wins <= 0:
            #         return True
            #
            # return remaining_wins <= 0

        @override
        def item_dependencies(self) -> dict[str, set[int]]:
            return {
                **{item.value: {id(self)} for item in RaceEvents},
                **{item.value: {id(self)} for item in StuntRunEvents},
                **{item.value: {id(self)} for item in RoadRageEvents},
                **{item.value: {id(self)} for item in MarkedManEvents},
                **{item.value: {id(self)} for item in BurningCars}
            }

        @override
        def __str__(self) -> str:
            return f"Must Win {self.wins} Events"
